-- CreateTable
CREATE TABLE `usuarios` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `nome` VARCHAR(150) NOT NULL,
    `email` VARCHAR(150) NOT NULL,
    `senhaHash` VARCHAR(255) NOT NULL,
    `papel` ENUM('ATENDENTE', 'GESTOR') NOT NULL DEFAULT 'ATENDENTE',
    `ativo` BOOLEAN NOT NULL DEFAULT true,
    `criadoEm` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `atualizadoEm` DATETIME(3) NOT NULL,

    UNIQUE INDEX `usuarios_email_key`(`email`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `clientes` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `nome` VARCHAR(150) NOT NULL,
    `cpf` VARCHAR(14) NOT NULL,
    `dataNascimento` DATE NOT NULL,
    `cnh` VARCHAR(20) NOT NULL,
    `validadeCnh` DATE NOT NULL,
    `telefone` VARCHAR(20) NOT NULL,
    `email` VARCHAR(150) NOT NULL,
    `situacao` ENUM('ATIVO', 'INATIVO') NOT NULL DEFAULT 'ATIVO',
    `criadoEm` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `atualizadoEm` DATETIME(3) NOT NULL,

    UNIQUE INDEX `clientes_cpf_key`(`cpf`),
    UNIQUE INDEX `clientes_cnh_key`(`cnh`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `veiculos` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `placa` VARCHAR(10) NOT NULL,
    `marca` VARCHAR(50) NOT NULL,
    `modelo` VARCHAR(80) NOT NULL,
    `ano` INTEGER NOT NULL,
    `quilometragem` INTEGER NOT NULL DEFAULT 0,
    `tarifaDiaria` DECIMAL(10, 2) NOT NULL,
    `situacao` ENUM('DISPONIVEL', 'LOCADO', 'EM_MANUTENCAO', 'BLOQUEADO') NOT NULL DEFAULT 'DISPONIVEL',
    `criadoEm` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `atualizadoEm` DATETIME(3) NOT NULL,

    UNIQUE INDEX `veiculos_placa_key`(`placa`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `locacoes` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `codigoContrato` VARCHAR(36) NOT NULL,
    `clienteId` INTEGER NOT NULL,
    `veiculoId` INTEGER NOT NULL,
    `retiradaPrevista` DATETIME(3) NOT NULL,
    `devolucaoPrevista` DATETIME(3) NOT NULL,
    `retiradaEfetiva` DATETIME(3) NULL,
    `devolucaoEfetiva` DATETIME(3) NULL,
    `kmInicial` INTEGER NULL,
    `kmFinal` INTEGER NULL,
    `diariasContratadas` INTEGER NOT NULL,
    `tarifaContratada` DECIMAL(10, 2) NOT NULL,
    `valorPrevisto` DECIMAL(10, 2) NOT NULL,
    `diariasAtraso` INTEGER NOT NULL DEFAULT 0,
    `valorAdicionalAtraso` DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    `valorFinal` DECIMAL(10, 2) NULL,
    `situacao` ENUM('CONFIRMADA', 'EM_ANDAMENTO', 'FINALIZADA', 'CANCELADA') NOT NULL DEFAULT 'CONFIRMADA',
    `motivoCancelamento` VARCHAR(255) NULL,
    `criadoEm` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `atualizadoEm` DATETIME(3) NOT NULL,

    UNIQUE INDEX `locacoes_codigoContrato_key`(`codigoContrato`),
    INDEX `locacoes_clienteId_idx`(`clienteId`),
    INDEX `locacoes_veiculoId_idx`(`veiculoId`),
    INDEX `locacoes_situacao_idx`(`situacao`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `manutencoes` (
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `veiculoId` INTEGER NOT NULL,
    `motivo` VARCHAR(255) NOT NULL,
    `pendenteAposLocacao` BOOLEAN NOT NULL DEFAULT false,
    `finalizada` BOOLEAN NOT NULL DEFAULT false,
    `dataInicio` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `dataFim` DATETIME(3) NULL,
    `registradoPorId` INTEGER NOT NULL,
    `criadoEm` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `atualizadoEm` DATETIME(3) NOT NULL,

    INDEX `manutencoes_veiculoId_idx`(`veiculoId`),
    INDEX `manutencoes_registradoPorId_idx`(`registradoPorId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `locacoes` ADD CONSTRAINT `locacoes_clienteId_fkey` FOREIGN KEY (`clienteId`) REFERENCES `clientes`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `locacoes` ADD CONSTRAINT `locacoes_veiculoId_fkey` FOREIGN KEY (`veiculoId`) REFERENCES `veiculos`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `manutencoes` ADD CONSTRAINT `manutencoes_veiculoId_fkey` FOREIGN KEY (`veiculoId`) REFERENCES `veiculos`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `manutencoes` ADD CONSTRAINT `manutencoes_registradoPorId_fkey` FOREIGN KEY (`registradoPorId`) REFERENCES `usuarios`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

