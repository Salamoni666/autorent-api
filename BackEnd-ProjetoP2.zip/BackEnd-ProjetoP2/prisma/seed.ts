import { PrismaClient, PapelUsuario, SituacaoCliente, SituacaoVeiculo } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando seed da base de dados AutoRent...');

  // 1. Criar Usuários padrão (Gestor e Atendente)
  const senhaHashGestor = await bcrypt.hash('admin123', 10);
  const senhaHashAtendente = await bcrypt.hash('atendente123', 10);

  const gestor = await prisma.usuario.upsert({
    where: { email: 'gestor@autorent.com' },
    update: {},
    create: {
      nome: 'Administrador Gestor',
      email: 'gestor@autorent.com',
      senhaHash: senhaHashGestor,
      papel: PapelUsuario.GESTOR,
      ativo: true,
    },
  });

  const atendente = await prisma.usuario.upsert({
    where: { email: 'atendente@autorent.com' },
    update: {},
    create: {
      nome: 'Carlos Atendente',
      email: 'atendente@autorent.com',
      senhaHash: senhaHashAtendente,
      papel: PapelUsuario.ATENDENTE,
      ativo: true,
    },
  });

  console.log('✅ Usuários criados: Gestor e Atendente');

  // 2. Criar Clientes Iniciais
  await prisma.cliente.upsert({
    where: { cpf: '111.222.333-44' },
    update: {},
    create: {
      nome: 'Mariana Souza Costa',
      cpf: '111.222.333-44',
      dataNascimento: new Date('1995-05-14T00:00:00.000Z'),
      cnh: '12345678900',
      validadeCnh: new Date('2028-12-31T00:00:00.000Z'),
      telefone: '(11) 98765-4321',
      email: 'mariana.costa@email.com',
      situacao: SituacaoCliente.ATIVO,
    },
  });

  await prisma.cliente.upsert({
    where: { cpf: '222.333.444-55' },
    update: {},
    create: {
      nome: 'Lucas Ferreira Lima',
      cpf: '222.333.444-55',
      dataNascimento: new Date('1990-10-22T00:00:00.000Z'),
      cnh: '98765432100',
      validadeCnh: new Date('2027-08-15T00:00:00.000Z'),
      telefone: '(11) 91234-5678',
      email: 'lucas.lima@email.com',
      situacao: SituacaoCliente.ATIVO,
    },
  });

  console.log('✅ Clientes criados');

  // 3. Criar Frota de Veículos
  await prisma.veiculo.upsert({
    where: { placa: 'BRA2E19' },
    update: {},
    create: {
      placa: 'BRA2E19',
      marca: 'Volkswagen',
      modelo: 'Gol 1.0 Flex',
      ano: 2023,
      quilometragem: 25000,
      tarifaDiaria: 110.00,
      situacao: SituacaoVeiculo.DISPONIVEL,
    },
  });

  await prisma.veiculo.upsert({
    where: { placa: 'RIO1A23' },
    update: {},
    create: {
      placa: 'RIO1A23',
      marca: 'Chevrolet',
      modelo: 'Onix 1.0 Turbo',
      ano: 2024,
      quilometragem: 14500,
      tarifaDiaria: 140.00,
      situacao: SituacaoVeiculo.DISPONIVEL,
    },
  });

  await prisma.veiculo.upsert({
    where: { placa: 'SPX9Z88' },
    update: {},
    create: {
      placa: 'SPX9Z88',
      marca: 'Toyota',
      modelo: 'Corolla XEi 2.0',
      ano: 2024,
      quilometragem: 11000,
      tarifaDiaria: 250.00,
      situacao: SituacaoVeiculo.DISPONIVEL,
    },
  });

  await prisma.veiculo.upsert({
    where: { placa: 'CUR4B56' },
    update: {},
    create: {
      placa: 'CUR4B56',
      marca: 'Jeep',
      modelo: 'Compass Longitude 1.3 Turbo',
      ano: 2023,
      quilometragem: 32000,
      tarifaDiaria: 320.00,
      situacao: SituacaoVeiculo.DISPONIVEL,
    },
  });

  console.log('✅ Frota de veículos criada');
  console.log('🎉 Seed concluído com sucesso!');
}

main()
  .catch((e) => {
    console.error('❌ Erro durante execução do seed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

