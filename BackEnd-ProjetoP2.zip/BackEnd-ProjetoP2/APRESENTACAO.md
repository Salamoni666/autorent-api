# 📊 Roteiro e Estrutura de Apresentação de Projeto — AutoRent API

**Disciplina:** Desenvolvimento Back-End  
**Professor:** Vinícius Hungaro  
**Duração da Apresentação:** 40 a 50 minutos  
**Equipe:** 4 integrantes  

---

## 🎯 Divisão de Tempo Sugerida (Total: 45 minutos)

| Bloco | Assunto | Responsável Sugerido | Duração |
| :--- | :--- | :--- | :--- |
| **1. Introdução** | Tema, contextualização do problema e objetivos | Integrante 1 | 8 min |
| **2. Arquitetura** | Camadas, tecnologias (Node/TS/Prisma/MySQL) e modelagem MER | Integrante 2 | 10 min |
| **3. Regras de Negócio** | Endpoints complexos (contratação atômica e devolução com atraso) | Integrante 3 | 12 min |
| **4. Demonstração Prática** | Swagger UI ao vivo, banco MySQL e inspeção de código | Integrante 4 (e grupo) | 12 min |
| **5. Fechamento & Perguntas** | Dúvidas da banca e considerações finais | Todos | 3 min |

---

## 📑 Roteiro Slide a Slide (Estrutura Obrigatória do Edital)

### Slide 1: Capa
- **Título:** AutoRent API — Sistema Inteligente de Gestão e Locação de Veículos
- **Subtítulo:** Projeto Prático P2 — Desenvolvimento Back-End
- **Professor:** Vinícius Hungaro
- **Integrantes do Grupo:** [Nome dos 4 alunos]
- **Instituição:** FATEC — Tecnologia em Sistemas para Internet (3º Termo)

---

### Slide 2: Contextualização do Problema
- **Cenário Real:** Locadoras de veículos enfrentam problemas críticos de concorrência de reservas, clientes inelegíveis, devoluções em atraso sem controle financeiro e falha na rastreabilidade de veículos avariados/em manutenção.
- **Dores Atendidas:**
  - Evitar sobreposição de reservas para o mesmo veículo no mesmo período.
  - Eliminar cadastros inconsistentes e condutores com CNH vencida ou menores de 21 anos.
  - Automatizar a cobrança de diárias excedentes por frações de 24 horas sem tolerância.
  - Integrar a devolução com bloqueio automático do veículo para manutenção.

---

### Slide 3: Objetivo do Projeto
- Centralizar o ciclo completo da locação:
  1. **Contratação** (reserva atômica e congelamento de tarifa);
  2. **Retirada** (verificação física e validação anti-antecipação);
  3. **Devolução** (apuração do odômetro e cálculo de atraso);
  4. **Encerramento / Manutenção** (consolidação financeira e liberação/bloqueio da frota).
- Operação corporativa via **Atendentes** e **Gestores** com controle de acesso baseado em papéis (RBAC).

---

### Slide 4: Tecnologias Utilizadas & Justificativas Técnicas
- **Node.js + TypeScript:** Tipagem estática, segurança contra erros em tempo de compilação e manutenibilidade.
- **Express:** Framework minimalista, rápido e com ampla compatibilidade de middlewares.
- **MySQL 8.0:** Banco relacional robusto com integridade referencial, foreign keys e precisão decimal.
- **Prisma ORM:** Mapeamento objeto-relacional com migrações declarativas, Client type-safe e suporte nativo a transações interativas (`prisma.$transaction`).
- **Swagger / OpenAPI 3.0:** Documentação visual, interativa e executável em `/docs`.
- **Zod:** Validação e parsing de esquemas de entrada na camada de borda da API.
- **JWT + bcryptjs:** Autenticação stateless com hash seguro de senhas salgadas.

---

### Slide 5: Arquitetura em Camadas & Padrões Adotados
- **Separação de Responsabilidades (SoC):**
  - `Routes` ➔ Roteamento e anotações OpenAPI/Swagger.
  - `Middlewares` ➔ Autenticação (JWT), autorização RBAC, validação de DTOs (Zod) e tratamento global de erros.
  - `Controllers` ➔ Recepção de dados HTTP, delegação ao serviço e formato de resposta.
  - `Services` ➔ **Core da aplicação:** todas as regras de negócio, cálculos e transações atômicas.
  - `Database / Prisma` ➔ Persistência e consultas type-safe.
- **Padrões de Projeto Adotados:**
  - *Dependency Inversion / Layered Architecture*
  - *Data Transfer Object (DTO)* via Zod
  - *Singleton* na conexão do Prisma Client
  - *Centralized Error Handling* com a classe `AppError`

---

### Slide 6: Modelagem do Banco de Dados (MER)
- Apresentação do diagrama relacional:
  - Tabela `usuarios` (Gestores e Atendentes)
  - Tabela `clientes` (CPF e CNH únicos, datas com tipo `Date`)
  - Tabela `veiculos` (Placa única, odômetro, tarifa diária em `Decimal(10,2)`)
  - Tabela `locacoes` (Código do contrato, datas previstas/efetivas, diárias e valores financeiros congelados)
  - Tabela `manutencoes` (Histórico de serviços mecânicos e pendências atreladas ao veículo)

---

### Slide 7: A Regra de Negócio Principal — Endpoint Complexo 1
#### `POST /locacoes` (Contratação Atômica)
- **Elegibilidade do Cliente:**
  - Idade calculada na data da retirada: **mínimo de 21 anos**.
  - Validade da CNH: **deve cobrir todo o período contratado** até a devolução prevista.
  - Situação cadastral: deve estar `ATIVO`.
- **Detecção de Conflito de Período `[início, fim)`:**
  - Regra matemática de sobreposição:  
    $$\text{novaRetirada} < \text{devolucaoExistente} \quad \text{E} \quad \text{novaDevolucao} > \text{retiradaExistente}$$
- **Cálculo de Diárias Contratadas:**
  $$\text{diárias} = \max\left(1, \; \lceil \text{horas} / 24 \rceil\right)$$
- **Transação Atômica (`prisma.$transaction`):** Garante que duas requisições simultâneas não consigam reservar o mesmo veículo (isolamento ACID).

---

### Slide 8: A Regra de Negócio Principal — Endpoint Complexo 2
#### `POST /locacoes/:id/devolucao` (Apuração de Atraso e Bloqueio)
- **Consistência de Odômetro:**
  - Valida rigorosamente se $\text{kmFinal} \ge \text{kmInicial}$ (rejeita odômetro adulterado/menor).
- **Cálculo de Atraso Sem Tolerância:**
  - Se $\text{devolucaoEfetiva} > \text{devolucaoPrevista}$:
    $$\text{diariasAtraso} = \lceil \text{horasAtraso} / 24 \rceil$$
    $$\text{valorAdicional} = \text{diariasAtraso} \times \text{tarifaContratada}$$
  - Devolução antecipada: **não concede abatimento** (garantia de receita mínima contratada).
- **Aplicação de Manutenção Pendente:**
  - Se durante a locação foi agendada manutenção pelo Gestor, na devolução o veículo é colocado imediatamente em `EM_MANUTENCAO`.

---

### Slide 9: Roteiro da Demonstração Prática (12 minutos)
*Abrir o navegador em `http://localhost:3000/docs`:*

1. **Login:** Gerar token JWT com `gestor@autorent.com` e autenticar no botão *Authorize* do Swagger.
2. **CA001 / CA002:** Cadastrar cliente válido; tentar repetir o CPF e mostrar o retorno `409 Conflict`.
3. **CA003 / CA004:** Criar locação para o veículo 1 de 01 a 04/dezembro; tentar criar outra locação com sobreposição (03 a 06/dezembro) e demonstrar a recusa por conflito.
4. **CA005 / CA006:** Tentar registrar retirada às 09:00 (sendo que a retirada prevista era 10:00) ➔ Erro 400 (retirada antecipada recusada). Enviar horário correto ➔ Sucesso (veículo muda para `LOCADO`).
5. **CA008 / CA009:** Tentar devolução com km menor ➔ Erro 400. Enviar km correta com 5 horas de atraso ➔ Sistema cobra 1 diária extra inteira e finaliza o contrato.
6. **Inspeção no Banco:** Mostrar as tabelas no MySQL Workbench ou Prisma Studio (`npm run prisma:studio`).

---

### Slide 10: Conclusão & Atendimento aos Requisitos
- ✅ 19 Endpoints implementados (superando os 13 mínimos).
- ✅ 3 CRUDs completos com todas as 5 operações (Create, Read All, Read by ID, Update, Delete).
- ✅ 2 Endpoints com alta complexidade algorítmica e transacional.
- ✅ TypeScript + MySQL + Prisma ORM + Swagger UI funcionando.
- ✅ Código no GitHub com README e ambiente Dockerizado.

