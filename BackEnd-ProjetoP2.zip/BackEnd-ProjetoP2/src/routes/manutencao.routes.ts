import { Router } from 'express';
import { ManutencaoController } from '../controllers/manutencao.controller.js';
import { authMiddleware, authorizeRoles } from '../middlewares/authMiddleware.js';
import { validateSchema } from '../middlewares/validateSchema.js';
import {
  createManutencaoSchema,
  finalizarManutencaoSchema,
} from '../schemas/manutencao.schema.js';
import { PapelUsuario } from '@prisma/client';

const manutencaoRoutes = Router();
const manutencaoController = new ManutencaoController();

manutencaoRoutes.use(authMiddleware);

/**
 * @swagger
 * tags:
 *   name: Manutenções
 *   description: Gestão de manutenção e bloqueio operacional de veículos (RF011, UC010)
 */

/**
 * @swagger
 * /manutencoes:
 *   post:
 *     summary: Registrar bloqueio/manutenção de um veículo (Exclusivo Gestor)
 *     description: Se o veículo estiver locado, registra como pendente e aplica o bloqueio automaticamente na devolução. Se estiver livre, bloqueia imediatamente.
 *     tags: [Manutenções]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - veiculoId
 *               - motivo
 *             properties:
 *               veiculoId:
 *                 type: integer
 *                 example: 1
 *               motivo:
 *                 type: string
 *                 example: "Revisão dos freios e suspensão"
 *     responses:
 *       201:
 *         description: Manutenção ou pendência registrada
 *       400:
 *         description: Veículo já em manutenção
 */
manutencaoRoutes.post(
  '/',
  authorizeRoles(PapelUsuario.GESTOR),
  validateSchema({ body: createManutencaoSchema }),
  manutencaoController.criar
);

/**
 * @swagger
 * /manutencoes:
 *   get:
 *     summary: Listagem de manutenções registradas
 *     tags: [Manutenções]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: veiculoId
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Lista de manutenções
 */
manutencaoRoutes.get('/', manutencaoController.listar);

/**
 * @swagger
 * /manutencoes/{id}:
 *   get:
 *     summary: Consulta individual de registro de manutenção
 *     tags: [Manutenções]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Dados da manutenção
 *       404:
 *         description: Manutenção não encontrada
 */
manutencaoRoutes.get('/:id', manutencaoController.buscarPorId);

/**
 * @swagger
 * /manutencoes/{id}/finalizar:
 *   put:
 *     summary: Finalizar manutenção e liberar o veículo para locações (Exclusivo Gestor)
 *     tags: [Manutenções]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               observacao:
 *                 type: string
 *                 example: "Pastilhas trocadas com sucesso"
 *     responses:
 *       200:
 *         description: Manutenção finalizada e veículo liberado
 *       400:
 *         description: Manutenção já finalizada
 */
manutencaoRoutes.put(
  '/:id/finalizar',
  authorizeRoles(PapelUsuario.GESTOR),
  validateSchema({ body: finalizarManutencaoSchema }),
  manutencaoController.finalizar
);

export { manutencaoRoutes };

