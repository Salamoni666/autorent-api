import { Router } from 'express';
import { AuthController } from '../controllers/auth.controller.js';
import { validateSchema } from '../middlewares/validateSchema.js';
import { loginSchema } from '../schemas/auth.schema.js';

const authRoutes = Router();
const authController = new AuthController();

/**
 * @swagger
 * tags:
 *   name: Autenticação
 *   description: Autenticação de atendentes e gestores
 */

/**
 * @swagger
 * /auth/login:
 *   post:
 *     summary: Realiza login de funcionário (Atendente ou Gestor)
 *     tags: [Autenticação]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - email
 *               - senha
 *             properties:
 *               email:
 *                 type: string
 *                 example: gestor@autorent.com
 *               senha:
 *                 type: string
 *                 example: admin123
 *     responses:
 *       200:
 *         description: Login bem-sucedido com token JWT retornado
 *       401:
 *         description: Credenciais inválidas
 */
authRoutes.post('/login', validateSchema({ body: loginSchema }), authController.login);

export { authRoutes };

