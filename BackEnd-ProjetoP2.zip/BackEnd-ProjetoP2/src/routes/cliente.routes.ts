import { Router } from 'express';
import { ClienteController } from '../controllers/cliente.controller.js';
import { authMiddleware, authorizeRoles } from '../middlewares/authMiddleware.js';
import { validateSchema } from '../middlewares/validateSchema.js';
import {
  createClienteSchema,
  updateClienteSchema,
  queryClienteSchema,
} from '../schemas/cliente.schema.js';
import { PapelUsuario } from '@prisma/client';

const clienteRoutes = Router();
const clienteController = new ClienteController();

// Todas as rotas de clientes requerem autenticação
clienteRoutes.use(authMiddleware);

/**
 * @swagger
 * tags:
 *   name: Clientes
 *   description: Gerenciamento de clientes da AutoRent (RF001, UC001, UC002)
 */

/**
 * @swagger
 * /clientes:
 *   post:
 *     summary: Cadastrar um novo cliente
 *     tags: [Clientes]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - nome
 *               - cpf
 *               - dataNascimento
 *               - cnh
 *               - validadeCnh
 *               - telefone
 *               - email
 *             properties:
 *               nome:
 *                 type: string
 *                 example: Mariana Souza Costa
 *               cpf:
 *                 type: string
 *                 example: 111.222.333-44
 *               dataNascimento:
 *                 type: string
 *                 format: date
 *                 example: 1995-05-14
 *               cnh:
 *                 type: string
 *                 example: 12345678900
 *               validadeCnh:
 *                 type: string
 *                 format: date
 *                 example: 2028-12-31
 *               telefone:
 *                 type: string
 *                 example: (11) 98765-4321
 *               email:
 *                 type: string
 *                 example: mariana.costa@email.com
 *     responses:
 *       201:
 *         description: Cliente cadastrado com sucesso
 *       409:
 *         description: CPF ou CNH já cadastrados
 */
clienteRoutes.post(
  '/',
  validateSchema({ body: createClienteSchema }),
  clienteController.criar
);

/**
 * @swagger
 * /clientes:
 *   get:
 *     summary: Listagem geral de clientes com filtros
 *     tags: [Clientes]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: nome
 *         schema:
 *           type: string
 *       - in: query
 *         name: cpf
 *         schema:
 *           type: string
 *       - in: query
 *         name: situacao
 *         schema:
 *           type: string
 *           enum: [ATIVO, INATIVO]
 *     responses:
 *       200:
 *         description: Lista de clientes retornada
 */
clienteRoutes.get(
  '/',
  validateSchema({ query: queryClienteSchema }),
  clienteController.listar
);

/**
 * @swagger
 * /clientes/{id}:
 *   get:
 *     summary: Consulta individual de cliente por ID
 *     tags: [Clientes]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Dados do cliente e histórico de locações
 *       404:
 *         description: Cliente não encontrado
 */
clienteRoutes.get('/:id', clienteController.buscarPorId);

/**
 * @swagger
 * /clientes/{id}:
 *   put:
 *     summary: Atualizar dados cadastrais do cliente
 *     tags: [Clientes]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               nome:
 *                 type: string
 *               telefone:
 *                 type: string
 *               email:
 *                 type: string
 *     responses:
 *       200:
 *         description: Cliente atualizado com sucesso
 */
clienteRoutes.put(
  '/:id',
  validateSchema({ body: updateClienteSchema }),
  clienteController.atualizar
);

/**
 * @swagger
 * /clientes/{id}:
 *   delete:
 *     summary: Inativar ou remover cliente (Exclusivo Gestor)
 *     tags: [Clientes]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Cliente inativado (se possuir histórico) ou removido fisicamente
 *       403:
 *         description: Acesso restrito a Gestores
 */
clienteRoutes.delete(
  '/:id',
  authorizeRoles(PapelUsuario.GESTOR),
  clienteController.remover
);

export { clienteRoutes };

