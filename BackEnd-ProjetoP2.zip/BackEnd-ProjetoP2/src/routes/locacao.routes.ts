import { Router } from 'express';
import { LocacaoController } from '../controllers/locacao.controller.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';
import { validateSchema } from '../middlewares/validateSchema.js';
import {
  createLocacaoSchema,
  registrarRetiradaSchema,
  registrarDevolucaoSchema,
  cancelarLocacaoSchema,
  queryLocacaoSchema,
} from '../schemas/locacao.schema.js';

const locacaoRoutes = Router();
const locacaoController = new LocacaoController();

locacaoRoutes.use(authMiddleware);

/**
 * @swagger
 * tags:
 *   name: Locações
 *   description: Ciclo de vida e regras de negócio de contratos de locação (RF004–RF010, UC005–UC009)
 */

/**
 * @swagger
 * /locacoes:
 *   post:
 *     summary: "[ENDPOINT COMPLEXO 1] Contratar locação com validação de elegibilidade, concorrência e transação atômica"
 *     description: Realiza a contratação atômica verificando idade mínima (21 anos), validade de CNH durante todo o período, disponibilidade temporal [início, fim), cálculo de diárias (teto(horas/24)) e congelamento da tarifa.
 *     tags: [Locações]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - clienteId
 *               - veiculoId
 *               - retiradaPrevista
 *               - devolucaoPrevista
 *             properties:
 *               clienteId:
 *                 type: integer
 *                 example: 1
 *               veiculoId:
 *                 type: integer
 *                 example: 1
 *               retiradaPrevista:
 *                 type: string
 *                 format: date-time
 *                 example: "2026-12-01T10:00:00Z"
 *               devolucaoPrevista:
 *                 type: string
 *                 format: date-time
 *                 example: "2026-12-04T10:00:00Z"
 *     responses:
 *       201:
 *         description: Contrato de locação confirmado com sucesso
 *       400:
 *         description: Inelegibilidade do cliente (idade < 21, CNH vencida) ou datas inconsistentes
 *       409:
 *         description: Conflito de período (veículo já reservado no intervalo)
 */
locacaoRoutes.post(
  '/',
  validateSchema({ body: createLocacaoSchema }),
  locacaoController.contratar
);

/**
 * @swagger
 * /locacoes:
 *   get:
 *     summary: Listagem geral de locações com filtros
 *     tags: [Locações]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: clienteId
 *         schema:
 *           type: integer
 *       - in: query
 *         name: veiculoId
 *         schema:
 *           type: integer
 *       - in: query
 *         name: situacao
 *         schema:
 *           type: string
 *           enum: [CONFIRMADA, EM_ANDAMENTO, FINALIZADA, CANCELADA]
 *       - in: query
 *         name: codigoContrato
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Lista de locações retornada
 */
locacaoRoutes.get(
  '/',
  validateSchema({ query: queryLocacaoSchema }),
  locacaoController.listar
);

/**
 * @swagger
 * /locacoes/{id}:
 *   get:
 *     summary: Consulta individual e detalhada do contrato de locação
 *     tags: [Locações]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Dados detalhados do contrato
 *       404:
 *         description: Locação não encontrada
 */
locacaoRoutes.get('/:id', locacaoController.buscarPorId);

/**
 * @swagger
 * /locacoes/{id}/retirada:
 *   post:
 *     summary: Registrar a retirada física do veículo (Início da locação)
 *     description: Valida que a retirada não é antecipada em relação ao horário previsto, registra km inicial e move o veículo para LOCADO e a locação para EM_ANDAMENTO.
 *     tags: [Locações]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - kmInicial
 *             properties:
 *               kmInicial:
 *                 type: integer
 *                 example: 25000
 *               retiradaEfetiva:
 *                 type: string
 *                 format: date-time
 *                 example: "2026-12-01T10:05:00Z"
 *     responses:
 *       200:
 *         description: Retirada confirmada e veículo locado
 *       400:
 *         description: Retirada antecipada, veículo indisponível ou situação inválida
 */
locacaoRoutes.post(
  '/:id/retirada',
  validateSchema({ body: registrarRetiradaSchema }),
  locacaoController.registrarRetirada
);

/**
 * @swagger
 * /locacoes/{id}/devolucao:
 *   post:
 *     summary: "[ENDPOINT COMPLEXO 2] Registrar devolução, apurar atraso sem tolerância e consolidar valor final"
 *     description: Valida kmFinal >= kmInicial, calcula atraso por frações de 24h sem tolerância (diárias adicionais), calcula total devido e aplica manutenção preventiva/bloqueio se necessário.
 *     tags: [Locações]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - kmFinal
 *             properties:
 *               kmFinal:
 *                 type: integer
 *                 example: 25480
 *               devolucaoEfetiva:
 *                 type: string
 *                 format: date-time
 *                 example: "2026-12-04T15:30:00Z"
 *               necessitaManutencao:
 *                 type: boolean
 *                 example: false
 *               motivoManutencao:
 *                 type: string
 *                 example: "Troca de óleo preventiva"
 *     responses:
 *       200:
 *         description: Devolução consolidada e contrato finalizado
 *       400:
 *         description: Quilometragem final inferior à inicial ou contrato em situação inválida
 */
locacaoRoutes.post(
  '/:id/devolucao',
  validateSchema({ body: registrarDevolucaoSchema }),
  locacaoController.registrarDevolucao
);

/**
 * @swagger
 * /locacoes/{id}/cancelar:
 *   post:
 *     summary: Cancelar contrato de locação confirmado
 *     description: Cancela um contrato com status Confirmada e libera o período reservado do veículo.
 *     tags: [Locações]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               motivo:
 *                 type: string
 *                 example: "Desistência da viagem pelo cliente"
 *     responses:
 *       200:
 *         description: Contrato cancelado e reserva liberada
 *       400:
 *         description: Contrato já em andamento ou finalizado
 */
locacaoRoutes.post(
  '/:id/cancelar',
  validateSchema({ body: cancelarLocacaoSchema }),
  locacaoController.cancelar
);

export { locacaoRoutes };

