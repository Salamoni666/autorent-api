import { Router } from 'express';
import { authRoutes } from './auth.routes.js';
import { clienteRoutes } from './cliente.routes.js';
import { veiculoRoutes } from './veiculo.routes.js';
import { locacaoRoutes } from './locacao.routes.js';
import { manutencaoRoutes } from './manutencao.routes.js';

const routes = Router();

// Rota de Healthcheck da API
routes.get('/health', (_req, res) => {
  res.status(200).json({
    status: 'online',
    timestamp: new Date().toISOString(),
    api: 'AutoRent API - FATEC TSI 3º Termo',
  });
});

routes.use('/auth', authRoutes);
routes.use('/clientes', clienteRoutes);
routes.use('/veiculos', veiculoRoutes);
routes.use('/locacoes', locacaoRoutes);
routes.use('/manutencoes', manutencaoRoutes);

export { routes };
