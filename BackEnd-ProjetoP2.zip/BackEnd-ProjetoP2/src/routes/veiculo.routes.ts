import { Router } from 'express';
import { VeiculoController } from '../controllers/veiculo.controller.js';
import { authMiddleware, authorizeRoles } from '../middlewares/authMiddleware.js';
import { validateSchema } from '../middlewares/validateSchema.js';
import {
  createVeiculoSchema,
  updateVeiculoSchema,
  queryVeiculoSchema,
  disponibilidadeVeiculoSchema,
} from '../schemas/veiculo.schema.js';
import { PapelUsuario } from '@prisma/client';

const veiculoRoutes = Router();
const veiculoController = new VeiculoController();

veiculoRoutes.use(authMiddleware);

/**
 * @swagger
 * tags:
 *   name: Veículos
 *   description: Gerenciamento da frota de veículos (RF002, RF003, UC003, UC004)
 */

/**
 * @swagger
 * /veiculos/disponibilidade:
 *   get:
 *     summary: Consultar disponibilidade de frota ou de veículo específico em um período [início, fim)
 *     tags: [Veículos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: inicio
 *         required: true
 *         schema:
 *           type: string
 *           format: date-time
 *           example: "2026-12-01T10:00:00Z"
 *       - in: query
 *         name: fim
 *         required: true
 *         schema:
 *           type: string
 *           format: date-time
 *           example: "2026-12-05T10:00:00Z"
 *       - in: query
 *         name: veiculoId
 *         required: false
 *         schema:
 *           type: integer
 *           example: 1
 *     responses:
 *       200:
 *         description: Consulta de disponibilidade realizada com sucesso
 */
veiculoRoutes.get(
  '/disponibilidade',
  validateSchema({ query: disponibilidadeVeiculoSchema }),
  veiculoController.consultarDisponibilidade
);

/**
 * @swagger
 * /veiculos:
 *   post:
 *     summary: Cadastrar um novo veículo na frota (Exclusivo Gestor)
 *     tags: [Veículos]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - placa
 *               - marca
 *               - modelo
 *               - ano
 *               - tarifaDiaria
 *             properties:
 *               placa:
 *                 type: string
 *                 example: BRA2E19
 *               marca:
 *                 type: string
 *                 example: Volkswagen
 *               modelo:
 *                 type: string
 *                 example: Gol 1.0 Flex
 *               ano:
 *                 type: integer
 *                 example: 2023
 *               quilometragem:
 *                 type: integer
 *                 example: 25000
 *               tarifaDiaria:
 *                 type: number
 *                 example: 110.00
 *     responses:
 *       201:
 *         description: Veículo cadastrado com sucesso
 *       409:
 *         description: Placa já cadastrada
 */
veiculoRoutes.post(
  '/',
  authorizeRoles(PapelUsuario.GESTOR),
  validateSchema({ body: createVeiculoSchema }),
  veiculoController.criar
);

/**
 * @swagger
 * /veiculos:
 *   get:
 *     summary: Listagem geral de veículos da frota com filtros
 *     tags: [Veículos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: marca
 *         schema:
 *           type: string
 *       - in: query
 *         name: modelo
 *         schema:
 *           type: string
 *       - in: query
 *         name: situacao
 *         schema:
 *           type: string
 *           enum: [DISPONIVEL, LOCADO, EM_MANUTENCAO, BLOQUEADO]
 *     responses:
 *       200:
 *         description: Lista de veículos retornada
 */
veiculoRoutes.get(
  '/',
  validateSchema({ query: queryVeiculoSchema }),
  veiculoController.listar
);

/**
 * @swagger
 * /veiculos/{id}:
 *   get:
 *     summary: Consulta individual de veículo por ID
 *     tags: [Veículos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Dados detalhados do veículo
 *       404:
 *         description: Veículo não encontrado
 */
veiculoRoutes.get('/:id', veiculoController.buscarPorId);

/**
 * @swagger
 * /veiculos/{id}:
 *   put:
 *     summary: Atualizar dados de um veículo (Exclusivo Gestor)
 *     tags: [Veículos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               tarifaDiaria:
 *                 type: number
 *                 example: 125.00
 *               quilometragem:
 *                 type: integer
 *                 example: 26000
 *     responses:
 *       200:
 *         description: Veículo atualizado com sucesso
 */
veiculoRoutes.put(
  '/:id',
  authorizeRoles(PapelUsuario.GESTOR),
  validateSchema({ body: updateVeiculoSchema }),
  veiculoController.atualizar
);

/**
 * @swagger
 * /veiculos/{id}:
 *   delete:
 *     summary: Bloquear ou remover veículo da frota (Exclusivo Gestor)
 *     tags: [Veículos]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Veículo bloqueado ou removido com sucesso
 */
veiculoRoutes.delete(
  '/:id',
  authorizeRoles(PapelUsuario.GESTOR),
  veiculoController.remover
);

export { veiculoRoutes };

