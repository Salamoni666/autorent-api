import { z } from 'zod';
import { SituacaoVeiculo } from '@prisma/client';

export const createVeiculoSchema = z.object({
  placa: z
    .string()
    .min(7, 'Placa deve ter no mínimo 7 caracteres')
    .max(10)
    .transform((val) => val.toUpperCase().replace(/[^A-Z0-9]/g, '')),
  marca: z.string().min(2, 'Marca obrigatória').max(50),
  modelo: z.string().min(2, 'Modelo obrigatório').max(80),
  ano: z.coerce.number().int().min(1980).max(new Date().getFullYear() + 1),
  quilometragem: z.coerce.number().int().min(0, 'Quilometragem não pode ser negativa').default(0),
  tarifaDiaria: z.coerce.number().positive('A tarifa diária deve ser um valor maior que zero'),
  situacao: z.nativeEnum(SituacaoVeiculo).optional().default(SituacaoVeiculo.DISPONIVEL),
});

export const updateVeiculoSchema = createVeiculoSchema.partial();

export const queryVeiculoSchema = z.object({
  marca: z.string().optional(),
  modelo: z.string().optional(),
  situacao: z.nativeEnum(SituacaoVeiculo).optional(),
});

export const disponibilidadeVeiculoSchema = z.object({
  inicio: z.string().datetime({ message: 'Data de início deve estar em formato ISO 8601' }),
  fim: z.string().datetime({ message: 'Data de término deve estar em formato ISO 8601' }),
  veiculoId: z.coerce.number().int().positive().optional(),
});

export type CreateVeiculoInput = z.infer<typeof createVeiculoSchema>;
export type UpdateVeiculoInput = z.infer<typeof updateVeiculoSchema>;
export type QueryVeiculoInput = z.infer<typeof queryVeiculoSchema>;
export type DisponibilidadeVeiculoInput = z.infer<typeof disponibilidadeVeiculoSchema>;

