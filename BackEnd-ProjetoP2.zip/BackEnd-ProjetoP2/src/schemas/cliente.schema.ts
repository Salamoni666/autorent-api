import { z } from 'zod';
import { SituacaoCliente } from '@prisma/client';

export const createClienteSchema = z.object({
  nome: z.string().min(3, 'O nome deve ter no mínimo 3 caracteres').max(150),
  cpf: z
    .string()
    .regex(/^\d{3}\.\d{3}\.\d{3}\-\d{2}$|^\d{11}$/, 'CPF deve estar no formato 000.000.000-00 ou 11 dígitos numéricos')
    .transform((val) => val.replace(/\D/g, '').replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4')),
  dataNascimento: z
    .string()
    .datetime({ message: 'Data de nascimento deve estar em formato ISO 8601 (YYYY-MM-DDTHH:mm:ss.sssZ)' })
    .or(z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Data de nascimento deve estar no formato YYYY-MM-DD'))
    .transform((val) => new Date(val)),
  cnh: z.string().min(5, 'CNH deve conter ao menos 5 caracteres').max(20),
  validadeCnh: z
    .string()
    .datetime({ message: 'Validade da CNH deve estar em formato ISO 8601' })
    .or(z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Validade da CNH deve estar no formato YYYY-MM-DD'))
    .transform((val) => new Date(val)),
  telefone: z.string().min(8, 'Telefone inválido').max(20),
  email: z.string().email('E-mail inválido').max(150),
  situacao: z.nativeEnum(SituacaoCliente).optional().default(SituacaoCliente.ATIVO),
});

export const updateClienteSchema = createClienteSchema.partial();

export const queryClienteSchema = z.object({
  nome: z.string().optional(),
  cpf: z.string().optional(),
  situacao: z.nativeEnum(SituacaoCliente).optional(),
});

export type CreateClienteInput = z.infer<typeof createClienteSchema>;
export type UpdateClienteInput = z.infer<typeof updateClienteSchema>;
export type QueryClienteInput = z.infer<typeof queryClienteSchema>;

