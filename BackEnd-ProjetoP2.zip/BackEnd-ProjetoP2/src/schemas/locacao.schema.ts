import { z } from 'zod';
import { SituacaoLocacao } from '@prisma/client';

export const createLocacaoSchema = z.object({
  clienteId: z.coerce.number().int().positive('ID do cliente inválido'),
  veiculoId: z.coerce.number().int().positive('ID do veículo inválido'),
  retiradaPrevista: z
    .string()
    .datetime({ message: 'Data/hora de retirada prevista deve estar em formato ISO 8601' })
    .transform((val) => new Date(val)),
  devolucaoPrevista: z
    .string()
    .datetime({ message: 'Data/hora de devolução prevista deve estar em formato ISO 8601' })
    .transform((val) => new Date(val)),
});

export const registrarRetiradaSchema = z.object({
  retiradaEfetiva: z
    .string()
    .datetime({ message: 'Data/hora da retirada deve estar em formato ISO 8601' })
    .optional()
    .transform((val) => (val ? new Date(val) : new Date())),
  kmInicial: z.coerce.number().int().min(0, 'Quilometragem inicial não pode ser negativa'),
});

export const registrarDevolucaoSchema = z.object({
  devolucaoEfetiva: z
    .string()
    .datetime({ message: 'Data/hora da devolução deve estar em formato ISO 8601' })
    .optional()
    .transform((val) => (val ? new Date(val) : new Date())),
  kmFinal: z.coerce.number().int().min(0, 'Quilometragem final não pode ser negativa'),
  necessitaManutencao: z.boolean().optional().default(false),
  motivoManutencao: z.string().optional(),
});

export const cancelarLocacaoSchema = z.object({
  motivo: z.string().min(3, 'Informe o motivo do cancelamento').max(255).optional(),
});

export const queryLocacaoSchema = z.object({
  clienteId: z.coerce.number().int().positive().optional(),
  veiculoId: z.coerce.number().int().positive().optional(),
  situacao: z.nativeEnum(SituacaoLocacao).optional(),
  codigoContrato: z.string().optional(),
});

export type CreateLocacaoInput = z.infer<typeof createLocacaoSchema>;
export type RegistrarRetiradaInput = z.infer<typeof registrarRetiradaSchema>;
export type RegistrarDevolucaoInput = z.infer<typeof registrarDevolucaoSchema>;
export type CancelarLocacaoInput = z.infer<typeof cancelarLocacaoSchema>;
export type QueryLocacaoInput = z.infer<typeof queryLocacaoSchema>;

