import { z } from 'zod';

export const createManutencaoSchema = z.object({
  veiculoId: z.coerce.number().int().positive('ID do veículo inválido'),
  motivo: z.string().min(5, 'Informe detalhadamente o motivo da manutenção').max(255),
});

export const finalizarManutencaoSchema = z.object({
  observacao: z.string().optional(),
});

export type CreateManutencaoInput = z.infer<typeof createManutencaoSchema>;
export type FinalizarManutencaoInput = z.infer<typeof finalizarManutencaoSchema>;

