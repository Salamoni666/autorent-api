import express from 'express';
import cors from 'cors';
import path from 'path';
import { routes } from './routes/index.js';
import { errorHandler } from './middlewares/errorHandler.js';
import { setupSwagger } from './swagger/swagger.js';

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir arquivos estáticos do frontend amigável
app.use(express.static(path.join(process.cwd(), 'public')));

// Configuração da Documentação Swagger
setupSwagger(app);

// Rotas da Aplicação
app.use(routes);

// Redirecionamento de fallback para a interface se não for rota de API
app.get('/', (_req, res) => {
  res.sendFile(path.join(process.cwd(), 'public', 'index.html'));
});

// Middleware Centralizado de Tratamento de Erros
app.use(errorHandler);

export { app };

