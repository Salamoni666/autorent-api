import { app } from './app.js';
import { env } from './config/env.js';
import { prisma } from './database/prisma.js';

const server = app.listen(env.PORT, () => {
  console.log(`=================================================`);
  console.log(`🚗 AutoRent API rodando na porta ${env.PORT}`);
  console.log(`📖 Documentação Swagger: http://localhost:${env.PORT}/docs`);
  console.log(`🩺 Healthcheck: http://localhost:${env.PORT}/health`);
  console.log(`=================================================`);
});

// Encerramento gracioso
const shutdown = async () => {
  console.log('\n🛑 Encerrando servidor e desconectando banco de dados...');
  server.close(async () => {
    await prisma.$disconnect();
    console.log('✅ Conexão com o banco finalizada. Processo encerrado.');
    process.exit(0);
  });
};

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

