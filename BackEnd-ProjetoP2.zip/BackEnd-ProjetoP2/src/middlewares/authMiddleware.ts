import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { PapelUsuario } from '@prisma/client';
import { env } from '../config/env.js';
import { AppError } from '../errors/AppError.js';

interface TokenPayload {
  id: number;
  nome: string;
  email: string;
  papel: PapelUsuario;
  iat: number;
  exp: number;
}

export function authMiddleware(req: Request, _res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    throw new AppError('Token de autenticação não fornecido', 401);
  }

  const [scheme, token] = authHeader.split(' ');

  if (scheme !== 'Bearer' || !token) {
    throw new AppError('Formato de token inválido. Utilize: Bearer <token>', 401);
  }

  try {
    const decoded = jwt.verify(token, env.JWT_SECRET) as TokenPayload;
    req.user = {
      id: decoded.id,
      nome: decoded.nome,
      email: decoded.email,
      papel: decoded.papel,
    };
    return next();
  } catch {
    throw new AppError('Token inválido ou expirado', 401);
  }
}

export function authorizeRoles(...rolesPermitidas: PapelUsuario[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) {
      throw new AppError('Usuário não autenticado', 401);
    }

    if (!rolesPermitidas.includes(req.user.papel)) {
      throw new AppError('Acesso negado: perfil de usuário sem permissão para esta operação', 403);
    }

    return next();
  };
}

