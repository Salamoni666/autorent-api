import { Request, Response, NextFunction } from 'express';
import { AppError } from '../errors/AppError.js';
import { ZodError } from 'zod';
import { Prisma } from '@prisma/client';

export function errorHandler(
  error: Error,
  _req: Request,
  res: Response,
  _next: NextFunction
) {
  if (error instanceof AppError) {
    return res.status(error.statusCode).json({
      status: 'error',
      message: error.message,
      ...(error.details ? { details: error.details } : {}),
    });
  }

  if (error instanceof ZodError) {
    return res.status(400).json({
      status: 'error',
      message: 'Erro de validação dos dados de entrada',
      errors: error.errors.map((err) => ({
        campo: err.path.join('.'),
        mensagem: err.message,
      })),
    });
  }

  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    if (error.code === 'P2002') {
      const target = (error.meta?.target as string[]) || 'campo único';
      return res.status(409).json({
        status: 'error',
        message: `Já existe um registro cadastrado com o mesmo valor para: ${target}`,
      });
    }

    if (error.code === 'P2025') {
      return res.status(404).json({
        status: 'error',
        message: 'Registro não encontrado no banco de dados',
      });
    }
  }

  console.error('💥 Erro não tratado:', error);

  return res.status(500).json({
    status: 'error',
    message: 'Ocorreu um erro interno no servidor',
  });
}

