import { prisma } from '../database/prisma.js';
import { AppError } from '../errors/AppError.js';
import {
  CreateLocacaoInput,
  RegistrarRetiradaInput,
  RegistrarDevolucaoInput,
  CancelarLocacaoInput,
  QueryLocacaoInput,
} from '../schemas/locacao.schema.js';
import { SituacaoCliente, SituacaoVeiculo, SituacaoLocacao } from '@prisma/client';

export class LocacaoService {
  // =========================================================================
  // ENDPOINT COMPLEXO 1: Contratação de Locação com Transação Atômica (RF004, UC005)
  // Regras: RN018–RN027, CA003, CA004, CA013
  // =========================================================================
  async contratar(dados: CreateLocacaoInput) {
    const agora = new Date();
    // Margem de 5 minutos para relógios dessincronizados
    const limitePassado = new Date(agora.getTime() - 5 * 60 * 1000);

    if (dados.retiradaPrevista < limitePassado) {
      throw new AppError('A data/hora de retirada prevista não pode estar no passado');
    }

    if (dados.devolucaoPrevista <= dados.retiradaPrevista) {
      throw new AppError('A data/hora de devolução deve ser posterior à de retirada');
    }

    // 1. Validar Elegibilidade do Cliente (RF001, RN003, RN004)
    const cliente = await prisma.cliente.findUnique({
      where: { id: dados.clienteId },
    });

    if (!cliente) {
      throw new AppError('Cliente não encontrado', 404);
    }

    if (cliente.situacao !== SituacaoCliente.ATIVO) {
      throw new AppError('Cliente com cadastro inativo não pode realizar locações', 400);
    }

    // Idade mínima de 21 anos na data de retirada
    const nascimento = new Date(cliente.dataNascimento);
    const idade =
      dados.retiradaPrevista.getFullYear() -
      nascimento.getFullYear() -
      (dados.retiradaPrevista <
      new Date(dados.retiradaPrevista.getFullYear(), nascimento.getMonth(), nascimento.getDate())
        ? 1
        : 0);

    if (idade < 21) {
      throw new AppError(
        `Cliente não possui a idade mínima de 21 anos para locação (idade atual na retirada: ${idade} anos)`,
        400
      );
    }

    // CNH deve ser válida durante TODO o período da locação (até a devolução prevista)
    if (new Date(cliente.validadeCnh) < dados.devolucaoPrevista) {
      throw new AppError(
        'A CNH do cliente expira antes da data de devolução prevista do veículo',
        400
      );
    }

    // 2. Transação Atômica para proteção de Concorrência e Reserva (CA013)
    return prisma.$transaction(async (tx: any) => {
      const veiculo = await tx.veiculo.findUnique({
        where: { id: dados.veiculoId },
      });

      if (!veiculo) {
        throw new AppError('Veículo não encontrado', 404);
      }

      if (veiculo.situacao === SituacaoVeiculo.EM_MANUTENCAO) {
        throw new AppError('Veículo está em manutenção e não pode ser locado (CA011)', 400);
      }

      if (veiculo.situacao === SituacaoVeiculo.BLOQUEADO) {
        throw new AppError('Veículo com bloqueio operacional ativo pelo Gestor', 400);
      }

      // Validação de Conflito de Período [início, fim)
      // Regra ERN: Conflito quando novaRetirada < devolucaoExistente E novaDevolucao > retiradaExistente
      const locacaoConflitante = await tx.locacao.findFirst({
        where: {
          veiculoId: dados.veiculoId,
          situacao: { in: [SituacaoLocacao.CONFIRMADA, SituacaoLocacao.EM_ANDAMENTO] },
          retiradaPrevista: { lt: dados.devolucaoPrevista },
          devolucaoPrevista: { gt: dados.retiradaPrevista },
        },
      });

      if (locacaoConflitante) {
        throw new AppError(
          `Conflito de período: o veículo já possui a reserva/contrato ${locacaoConflitante.codigoContrato} neste intervalo (CA004)`,
          409
        );
      }

      // Cálculo das Diárias Contratadas (RF009 / RN024)
      // Diárias = máximo(1, teto(horas contratadas / 24))
      const diffMs = dados.devolucaoPrevista.getTime() - dados.retiradaPrevista.getTime();
      const diffHoras = diffMs / (1000 * 60 * 60);
      const diariasContratadas = Math.max(1, Math.ceil(diffHoras / 24));

      // Congelamento da Tarifa e Cálculo do Valor Previsto
      const tarifaContratada = Number(veiculo.tarifaDiaria);
      const valorPrevisto = Number((diariasContratadas * tarifaContratada).toFixed(2));

      // Geração de Código Único de Contrato
      const codigoContrato = `LOC-${Date.now().toString(36).toUpperCase()}-${Math.random()
        .toString(36)
        .substring(2, 6)
        .toUpperCase()}`;

      const locacao = await tx.locacao.create({
        data: {
          codigoContrato,
          clienteId: dados.clienteId,
          veiculoId: dados.veiculoId,
          retiradaPrevista: dados.retiradaPrevista,
          devolucaoPrevista: dados.devolucaoPrevista,
          diariasContratadas,
          tarifaContratada,
          valorPrevisto,
          situacao: SituacaoLocacao.CONFIRMADA,
        },
        include: {
          cliente: {
            select: { id: true, nome: true, cpf: true, cnh: true },
          },
          veiculo: {
            select: { id: true, placa: true, marca: true, modelo: true, tarifaDiaria: true },
          },
        },
      });

      return locacao;
    });
  }

  // =========================================================================
  // Registrar Retirada (RF007 / UC007)
  // Regras: RN030–RN037, CA005, CA006
  // =========================================================================
  async registrarRetirada(id: number, dados: RegistrarRetiradaInput) {
    const locacao = await prisma.locacao.findUnique({
      where: { id },
      include: { veiculo: true },
    });

    if (!locacao) {
      throw new AppError('Locação não encontrada', 404);
    }

    if (locacao.situacao !== SituacaoLocacao.CONFIRMADA) {
      throw new AppError(
        `Retirada só pode ser registrada em contratos com situação Confirmada. Situação atual: ${locacao.situacao}`,
        400
      );
    }

    const horarioRetirada = dados.retiradaEfetiva || new Date();

    // Regra CA005: Retirada não pode ser antecipada em relação ao horário previsto
    if (horarioRetirada < locacao.retiradaPrevista) {
      throw new AppError(
        `Retirada antecipada não permitida. Horário previsto: ${locacao.retiradaPrevista.toISOString()}`,
        400
      );
    }

    // Retirada não pode ocorrer após o término previsto da locação
    if (horarioRetirada >= locacao.devolucaoPrevista) {
      throw new AppError(
        'O prazo de retirada expirou (horário de retirada ultrapassa a data de devolução prevista)',
        400
      );
    }

    return prisma.$transaction(async (tx: any) => {
      const veiculoAtual = await tx.veiculo.findUnique({
        where: { id: locacao.veiculoId },
      });

      if (!veiculoAtual || veiculoAtual.situacao === SituacaoVeiculo.LOCADO) {
        throw new AppError('O veículo não está fisicamente disponível para retirada', 400);
      }

      if (veiculoAtual.situacao === SituacaoVeiculo.EM_MANUTENCAO || veiculoAtual.situacao === SituacaoVeiculo.BLOQUEADO) {
        throw new AppError('O veículo possui restrição operacional ativa e não pode ser entregue', 400);
      }

      // Atualiza Locação para EM_ANDAMENTO
      const locacaoAtualizada = await tx.locacao.update({
        where: { id },
        data: {
          situacao: SituacaoLocacao.EM_ANDAMENTO,
          retiradaEfetiva: horarioRetirada,
          kmInicial: dados.kmInicial,
        },
      });

      // Atualiza Veículo para LOCADO e atualiza odômetro
      await tx.veiculo.update({
        where: { id: locacao.veiculoId },
        data: {
          situacao: SituacaoVeiculo.LOCADO,
          quilometragem: Math.max(veiculoAtual.quilometragem, dados.kmInicial),
        },
      });

      return locacaoAtualizada;
    });
  }

  // =========================================================================
  // ENDPOINT COMPLEXO 2: Registro de Devolução com Cálculo de Atraso e Bloqueio (RF008, RF010, UC008, UC009)
  // Regras: RN038–RN048, CA007, CA008, CA009, CA010
  // =========================================================================
  async registrarDevolucao(id: number, dados: RegistrarDevolucaoInput, gestorId?: number) {
    const locacao = await prisma.locacao.findUnique({
      where: { id },
      include: { veiculo: true },
    });

    if (!locacao) {
      throw new AppError('Locação não encontrada', 404);
    }

    if (locacao.situacao !== SituacaoLocacao.EM_ANDAMENTO) {
      throw new AppError(
        `Devolução permitida apenas para locações 'Em andamento'. Situação atual: ${locacao.situacao} (CA012)`,
        400
      );
    }

    const devolucaoEfetiva = dados.devolucaoEfetiva || new Date();
    const retiradaEfetiva = locacao.retiradaEfetiva || locacao.retiradaPrevista;

    if (devolucaoEfetiva < retiradaEfetiva) {
      throw new AppError('A data de devolução não pode ser anterior à data da retirada', 400);
    }

    // Regra CA009: Quilometragem final >= quilometragem inicial
    const kmInicial = locacao.kmInicial ?? locacao.veiculo.quilometragem;
    if (dados.kmFinal < kmInicial) {
      throw new AppError(
        `Quilometragem final (${dados.kmFinal} km) não pode ser inferior à inicial (${kmInicial} km) (CA009)`,
        400
      );
    }

    // Cálculo de Atraso e Diárias Excedentes (RF010, RN042–RN045, CA008)
    // Sem tolerância: qualquer fração de 24 horas de atraso = 1 diária adicional inteira
    let diariasAtraso = 0;
    let valorAdicionalAtraso = 0;

    const diffAtrasoMs = devolucaoEfetiva.getTime() - locacao.devolucaoPrevista.getTime();
    if (diffAtrasoMs > 0) {
      const horasAtraso = diffAtrasoMs / (1000 * 60 * 60);
      diariasAtraso = Math.ceil(horasAtraso / 24);
      valorAdicionalAtraso = Number((diariasAtraso * Number(locacao.tarifaContratada)).toFixed(2));
    }

    // Devolução antecipada: não há desconto (RN044)
    const valorPrevisto = Number(locacao.valorPrevisto);
    const valorFinal = Number((valorPrevisto + valorAdicionalAtraso).toFixed(2));

    return prisma.$transaction(async (tx: any) => {
      // 1. Finaliza a Locação
      const locacaoFinalizada = await tx.locacao.update({
        where: { id },
        data: {
          situacao: SituacaoLocacao.FINALIZADA,
          devolucaoEfetiva,
          kmFinal: dados.kmFinal,
          diariasAtraso,
          valorAdicionalAtraso,
          valorFinal,
        },
      });

      // 2. Verificar se há manutenção pendente agendada durante a locação (RN050)
      const manutencaoPendente = await tx.manutencao.findFirst({
        where: {
          veiculoId: locacao.veiculoId,
          pendenteAposLocacao: true,
          finalizada: false,
        },
      });

      let novaSituacaoVeiculo: SituacaoVeiculo = SituacaoVeiculo.DISPONIVEL;

      if (dados.necessitaManutencao || manutencaoPendente) {
        novaSituacaoVeiculo = SituacaoVeiculo.EM_MANUTENCAO;

        if (dados.necessitaManutencao && !manutencaoPendente) {
          await tx.manutencao.create({
            data: {
              veiculoId: locacao.veiculoId,
              motivo: dados.motivoManutencao || 'Manutenção preventiva indicada na devolução do veículo',
              pendenteAposLocacao: false,
              finalizada: false,
              registradoPorId: gestorId || 1,
            },
          });
        }
      }

      // 3. Atualizar o Veículo com a nova quilometragem e situação
      await tx.veiculo.update({
        where: { id: locacao.veiculoId },
        data: {
          quilometragem: dados.kmFinal,
          situacao: novaSituacaoVeiculo,
        },
      });

      return locacaoFinalizada;
    });
  }

  // =========================================================================
  // Cancelar Locação (RF006 / UC006)
  // Regras: RN028, RN029, CA012
  // =========================================================================
  async cancelar(id: number, dados: CancelarLocacaoInput) {
    const locacao = await prisma.locacao.findUnique({
      where: { id },
    });

    if (!locacao) {
      throw new AppError('Locação não encontrada', 404);
    }

    if (locacao.situacao !== SituacaoLocacao.CONFIRMADA) {
      throw new AppError(
        `Apenas contratos com situação 'Confirmada' podem ser cancelados. Situação atual: ${locacao.situacao} (CA012)`,
        400
      );
    }

    return prisma.locacao.update({
      where: { id },
      data: {
        situacao: SituacaoLocacao.CANCELADA,
        motivoCancelamento: dados.motivo || 'Cancelado a pedido do cliente/atendente',
      },
    });
  }

  async listar(filtros: QueryLocacaoInput) {
    const where: any = {};

    if (filtros.clienteId) {
      where.clienteId = filtros.clienteId;
    }

    if (filtros.veiculoId) {
      where.veiculoId = filtros.veiculoId;
    }

    if (filtros.situacao) {
      where.situacao = filtros.situacao;
    }

    if (filtros.codigoContrato) {
      where.codigoContrato = { contains: filtros.codigoContrato };
    }

    return prisma.locacao.findMany({
      where,
      include: {
        cliente: {
          select: { id: true, nome: true, cpf: true, email: true },
        },
        veiculo: {
          select: { id: true, placa: true, marca: true, modelo: true, situacao: true },
        },
      },
      orderBy: { criadoEm: 'desc' },
    });
  }

  async buscarPorId(id: number) {
    const locacao = await prisma.locacao.findUnique({
      where: { id },
      include: {
        cliente: true,
        veiculo: true,
      },
    });

    if (!locacao) {
      throw new AppError('Locação não encontrada', 404);
    }

    return locacao;
  }
}
