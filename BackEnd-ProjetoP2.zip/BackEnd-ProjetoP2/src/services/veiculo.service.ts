import { prisma } from '../database/prisma.js';
import { AppError } from '../errors/AppError.js';
import {
  CreateVeiculoInput,
  UpdateVeiculoInput,
  QueryVeiculoInput,
  DisponibilidadeVeiculoInput,
} from '../schemas/veiculo.schema.js';
import { SituacaoVeiculo, SituacaoLocacao } from '@prisma/client';

export class VeiculoService {
  async criar(dados: CreateVeiculoInput) {
    const placaExistente = await prisma.veiculo.findUnique({
      where: { placa: dados.placa },
    });

    if (placaExistente) {
      throw new AppError('Já existe um veículo cadastrado com esta placa', 409);
    }

    return prisma.veiculo.create({
      data: dados,
    });
  }

  async listar(filtros: QueryVeiculoInput) {
    const where: any = {};

    if (filtros.marca) {
      where.marca = { contains: filtros.marca };
    }

    if (filtros.modelo) {
      where.modelo = { contains: filtros.modelo };
    }

    if (filtros.situacao) {
      where.situacao = filtros.situacao;
    }

    return prisma.veiculo.findMany({
      where,
      orderBy: { modelo: 'asc' },
    });
  }

  async buscarPorId(id: number) {
    const veiculo = await prisma.veiculo.findUnique({
      where: { id },
      include: {
        manutencoes: {
          take: 5,
          orderBy: { criadoEm: 'desc' },
        },
      },
    });

    if (!veiculo) {
      throw new AppError('Veículo não encontrado', 404);
    }

    return veiculo;
  }

  async atualizar(id: number, dados: UpdateVeiculoInput) {
    await this.buscarPorId(id);

    if (dados.placa) {
      const placaOcupada = await prisma.veiculo.findFirst({
        where: { placa: dados.placa, NOT: { id } },
      });
      if (placaOcupada) {
        throw new AppError('Esta placa já está sendo utilizada por outro veículo', 409);
      }
    }

    // A atualização da tarifa não afeta contratos já confirmados ou históricos (RN014)
    return prisma.veiculo.update({
      where: { id },
      data: dados,
    });
  }

  async inativarOuRemover(id: number) {
    await this.buscarPorId(id);

    const locacoesVinculadas = await prisma.locacao.count({
      where: { veiculoId: id },
    });

    // Conforme ERN RF002: preservar veículos vinculados a contratos
    if (locacoesVinculadas > 0) {
      return prisma.veiculo.update({
        where: { id },
        data: { situacao: SituacaoVeiculo.BLOQUEADO },
      });
    }

    return prisma.veiculo.delete({
      where: { id },
    });
  }

  // RF003 & UC004 - Consultar Disponibilidade Operacional e Temporal
  async consultarDisponibilidade(params: DisponibilidadeVeiculoInput) {
    const inicio = new Date(params.inicio);
    const fim = new Date(params.fim);

    if (isNaN(inicio.getTime()) || isNaN(fim.getTime())) {
      throw new AppError('Período de consulta inválido');
    }

    if (inicio >= fim) {
      throw new AppError('A data/hora de término deve ser posterior à data/hora de início');
    }

    // Se informou um veículo específico
    if (params.veiculoId) {
      const veiculo = await this.buscarPorId(params.veiculoId);

      if (veiculo.situacao === SituacaoVeiculo.EM_MANUTENCAO) {
        return {
          veiculoId: veiculo.id,
          disponivel: false,
          motivo: 'Veículo está atualmente em manutenção (CA011)',
        };
      }

      if (veiculo.situacao === SituacaoVeiculo.BLOQUEADO) {
        return {
          veiculoId: veiculo.id,
          disponivel: false,
          motivo: 'Veículo com bloqueio operacional ativo pelo Gestor',
        };
      }

      // Regra de sobreposição de intervalo [início, fim):
      // novaRetirada < devolucaoExistente E novaDevolucao > retiradaExistente
      const locacaoConflitante = await prisma.locacao.findFirst({
        where: {
          veiculoId: veiculo.id,
          situacao: { in: [SituacaoLocacao.CONFIRMADA, SituacaoLocacao.EM_ANDAMENTO] },
          retiradaPrevista: { lt: fim },
          devolucaoPrevista: { gt: inicio },
        },
      });

      if (locacaoConflitante) {
        return {
          veiculoId: veiculo.id,
          disponivel: false,
          motivo: `Conflito de período com locação existente (${locacaoConflitante.codigoContrato})`,
        };
      }

      return {
        veiculoId: veiculo.id,
        disponivel: true,
        veiculo,
      };
    }

    // Caso de listagem de frota disponível no período
    const veiculosAptos = await prisma.veiculo.findMany({
      where: {
        situacao: { notIn: [SituacaoVeiculo.EM_MANUTENCAO, SituacaoVeiculo.BLOQUEADO] },
        locacoes: {
          none: {
            situacao: { in: [SituacaoLocacao.CONFIRMADA, SituacaoLocacao.EM_ANDAMENTO] },
            retiradaPrevista: { lt: fim },
            devolucaoPrevista: { gt: inicio },
          },
        },
      },
      orderBy: { tarifaDiaria: 'asc' },
    });

    return {
      periodo: { inicio, fim },
      totalDisponiveis: veiculosAptos.length,
      veiculos: veiculosAptos,
    };
  }
}

