import { prisma } from '../database/prisma.js';
import { AppError } from '../errors/AppError.js';
import { CreateClienteInput, UpdateClienteInput, QueryClienteInput } from '../schemas/cliente.schema.js';
import { SituacaoCliente } from '@prisma/client';

export class ClienteService {
  async criar(dados: CreateClienteInput) {
    const cpfExistente = await prisma.cliente.findUnique({
      where: { cpf: dados.cpf },
    });

    if (cpfExistente) {
      throw new AppError('Já existe um cliente cadastrado com este CPF', 409);
    }

    const cnhExistente = await prisma.cliente.findUnique({
      where: { cnh: dados.cnh },
    });

    if (cnhExistente) {
      throw new AppError('Já existe um cliente cadastrado com esta CNH', 409);
    }

    return prisma.cliente.create({
      data: dados,
    });
  }

  async listar(filtros: QueryClienteInput) {
    const where: any = {};

    if (filtros.nome) {
      where.nome = { contains: filtros.nome };
    }

    if (filtros.cpf) {
      where.cpf = { contains: filtros.cpf };
    }

    if (filtros.situacao) {
      where.situacao = filtros.situacao;
    }

    return prisma.cliente.findMany({
      where,
      orderBy: { nome: 'asc' },
    });
  }

  async buscarPorId(id: number) {
    const cliente = await prisma.cliente.findUnique({
      where: { id },
      include: {
        locacoes: {
          take: 10,
          orderBy: { criadoEm: 'desc' },
          include: {
            veiculo: {
              select: { placa: true, marca: true, modelo: true },
            },
          },
        },
      },
    });

    if (!cliente) {
      throw new AppError('Cliente não encontrado', 404);
    }

    return cliente;
  }

  async atualizar(id: number, dados: UpdateClienteInput) {
    await this.buscarPorId(id);

    if (dados.cpf) {
      const cpfOcupado = await prisma.cliente.findFirst({
        where: { cpf: dados.cpf, NOT: { id } },
      });
      if (cpfOcupado) {
        throw new AppError('Este CPF já está sendo utilizado por outro cliente', 409);
      }
    }

    if (dados.cnh) {
      const cnhOcupada = await prisma.cliente.findFirst({
        where: { cnh: dados.cnh, NOT: { id } },
      });
      if (cnhOcupada) {
        throw new AppError('Esta CNH já está sendo utilizada por outro cliente', 409);
      }
    }

    return prisma.cliente.update({
      where: { id },
      data: dados,
    });
  }

  async inativarOuRemover(id: number) {
    const cliente = await this.buscarPorId(id);

    const totalLocacoes = await prisma.locacao.count({
      where: { clienteId: id },
    });

    // Conforme ERN RF001: exclusão física impedida quando existir histórico
    if (totalLocacoes > 0) {
      return prisma.cliente.update({
        where: { id },
        data: { situacao: SituacaoCliente.INATIVO },
      });
    }

    return prisma.cliente.delete({
      where: { id },
    });
  }
}

