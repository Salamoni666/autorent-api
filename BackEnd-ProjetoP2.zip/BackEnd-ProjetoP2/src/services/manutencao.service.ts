import { prisma } from '../database/prisma.js';
import { AppError } from '../errors/AppError.js';
import { CreateManutencaoInput, FinalizarManutencaoInput } from '../schemas/manutencao.schema.js';
import { SituacaoVeiculo } from '@prisma/client';

export class ManutencaoService {
  async criar(dados: CreateManutencaoInput, gestorId: number) {
    const veiculo = await prisma.veiculo.findUnique({
      where: { id: dados.veiculoId },
    });

    if (!veiculo) {
      throw new AppError('Veículo não encontrado', 404);
    }

    if (veiculo.situacao === SituacaoVeiculo.EM_MANUTENCAO) {
      throw new AppError('Veículo já está em manutenção', 400);
    }

    return prisma.$transaction(async (tx: any) => {
      // Regra RN050: Se o veículo estiver atualmente locado, o bloqueio fica pendente até a devolução
      const isLocado = veiculo.situacao === SituacaoVeiculo.LOCADO;

      const manutencao = await tx.manutencao.create({
        data: {
          veiculoId: dados.veiculoId,
          motivo: dados.motivo,
          pendenteAposLocacao: isLocado,
          finalizada: false,
          registradoPorId: gestorId,
        },
      });

      if (!isLocado) {
        await tx.veiculo.update({
          where: { id: dados.veiculoId },
          data: { situacao: SituacaoVeiculo.EM_MANUTENCAO },
        });
      }

      return {
        manutencao,
        mensagem: isLocado
          ? 'Manutenção registrada como pendente. O veículo será bloqueado automaticamente na devolução da locação em andamento.'
          : 'Manutenção registrada e veículo bloqueado com sucesso.',
      };
    });
  }

  async listar(veiculoId?: number) {
    const where: any = {};
    if (veiculoId) {
      where.veiculoId = veiculoId;
    }

    return prisma.manutencao.findMany({
      where,
      include: {
        veiculo: {
          select: { id: true, placa: true, modelo: true, situacao: true },
        },
        registradoPor: {
          select: { id: true, nome: true, email: true },
        },
      },
      orderBy: { criadoEm: 'desc' },
    });
  }

  async buscarPorId(id: number) {
    const manutencao = await prisma.manutencao.findUnique({
      where: { id },
      include: {
        veiculo: true,
        registradoPor: {
          select: { id: true, nome: true, email: true },
        },
      },
    });

    if (!manutencao) {
      throw new AppError('Registro de manutenção não encontrado', 404);
    }

    return manutencao;
  }

  async finalizar(id: number, _dados?: FinalizarManutencaoInput) {
    const manutencao = await this.buscarPorId(id);

    if (manutencao.finalizada) {
      throw new AppError('Esta manutenção já foi finalizada anteriormente', 400);
    }

    return prisma.$transaction(async (tx: any) => {
      const manutencaoFinalizada = await tx.manutencao.update({
        where: { id },
        data: {
          finalizada: true,
          dataFim: new Date(),
        },
      });

      // Verifica se existem outras manutenções ativas para o mesmo veículo
      const outrasAtivas = await tx.manutencao.count({
        where: {
          veiculoId: manutencao.veiculoId,
          finalizada: false,
        },
      });

      if (outrasAtivas === 0) {
        await tx.veiculo.update({
          where: { id: manutencao.veiculoId },
          data: { situacao: SituacaoVeiculo.DISPONIVEL },
        });
      }

      return manutencaoFinalizada;
    });
  }
}
