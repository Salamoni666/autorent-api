import { PapelUsuario } from '@prisma/client';

declare global {
  namespace Express {
    interface Request {
      user?: {
        id: number;
        nome: string;
        email: string;
        papel: PapelUsuario;
      };
    }
  }
}

export {};

