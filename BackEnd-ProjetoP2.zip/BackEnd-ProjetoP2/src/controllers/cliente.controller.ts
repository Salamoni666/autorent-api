import { Request, Response, NextFunction } from 'express';
import { ClienteService } from '../services/cliente.service.js';

const clienteService = new ClienteService();

export class ClienteController {
  async criar(req: Request, res: Response, next: NextFunction) {
    try {
      const cliente = await clienteService.criar(req.body);
      return res.status(201).json({
        status: 'success',
        data: cliente,
      });
    } catch (error) {
      return next(error);
    }
  }

  async listar(req: Request, res: Response, next: NextFunction) {
    try {
      const clientes = await clienteService.listar(req.query);
      return res.status(200).json({
        status: 'success',
        total: clientes.length,
        data: clientes,
      });
    } catch (error) {
      return next(error);
    }
  }

  async buscarPorId(req: Request, res: Response, next: NextFunction) {
    try {
      const id = Number(req.params.id);
      const cliente = await clienteService.buscarPorId(id);
      return res.status(200).json({
        status: 'success',
        data: cliente,
      });
    } catch (error) {
      return next(error);
    }
  }

  async atualizar(req: Request, res: Response, next: NextFunction) {
    try {
      const id = Number(req.params.id);
      const cliente = await clienteService.atualizar(id, req.body);
      return res.status(200).json({
        status: 'success',
        message: 'Cliente atualizado com sucesso',
        data: cliente,
      });
    } catch (error) {
      return next(error);
    }
  }

  async remover(req: Request, res: Response, next: NextFunction) {
    try {
      const id = Number(req.params.id);
      const resultado = await clienteService.inativarOuRemover(id);
      return res.status(200).json({
        status: 'success',
        message: 'Cliente inativado ou removido com sucesso',
        data: resultado,
      });
    } catch (error) {
      return next(error);
    }
  }
}

