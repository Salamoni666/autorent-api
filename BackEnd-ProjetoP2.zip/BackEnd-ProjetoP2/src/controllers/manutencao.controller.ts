import { Request, Response, NextFunction } from 'express';
import { ManutencaoService } from '../services/manutencao.service.js';

const manutencaoService = new ManutencaoService();

export class ManutencaoController {
  async criar(req: Request, res: Response, next: NextFunction) {
    try {
      const gestorId = req.user?.id || 1;
      const resultado = await manutencaoService.criar(req.body, gestorId);
      return res.status(201).json({
        status: 'success',
        message: resultado.mensagem,
        data: resultado.manutencao,
      });
    } catch (error) {
      return next(error);
    }
  }

  async listar(req: Request, res: Response, next: NextFunction) {
    try {
      const veiculoId = req.query.veiculoId ? Number(req.query.veiculoId) : undefined;
      const manutençoes = await manutencaoService.listar(veiculoId);
      return res.status(200).json({
        status: 'success',
        total: manutençoes.length,
        data: manutençoes,
      });
    } catch (error) {
      return next(error);
    }
  }

  async buscarPorId(req: Request, res: Response, next: NextFunction) {
    try {
      const id = Number(req.params.id);
      const manutencao = await manutencaoService.buscarPorId(id);
      return res.status(200).json({
        status: 'success',
        data: manutencao,
      });
    } catch (error) {
      return next(error);
    }
  }

  async finalizar(req: Request, res: Response, next: NextFunction) {
    try {
      const id = Number(req.params.id);
      const manutencao = await manutencaoService.finalizar(id, req.body);
      return res.status(200).json({
        status: 'success',
        message: 'Manutenção finalizada e veículo liberado com sucesso',
        data: manutencao,
      });
    } catch (error) {
      return next(error);
    }
  }
}

