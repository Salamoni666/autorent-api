import { Request, Response, NextFunction } from 'express';
import { LocacaoService } from '../services/locacao.service.js';

const locacaoService = new LocacaoService();

export class LocacaoController {
  // POST /locacoes - Contratação (Endpoint Complexo 1)
  async contratar(req: Request, res: Response, next: NextFunction) {
    try {
      const locacao = await locacaoService.contratar(req.body);
      return res.status(201).json({
        status: 'success',
        message: 'Contrato de locação confirmado com sucesso',
        data: locacao,
      });
    } catch (error) {
      return next(error);
    }
  }

  // GET /locacoes
  async listar(req: Request, res: Response, next: NextFunction) {
    try {
      const locacoes = await locacaoService.listar(req.query as any);
      return res.status(200).json({
        status: 'success',
        total: locacoes.length,
        data: locacoes,
      });
    } catch (error) {
      return next(error);
    }
  }

  // GET /locacoes/:id
  async buscarPorId(req: Request, res: Response, next: NextFunction) {
    try {
      const id = Number(req.params.id);
      const locacao = await locacaoService.buscarPorId(id);
      return res.status(200).json({
        status: 'success',
        data: locacao,
      });
    } catch (error) {
      return next(error);
    }
  }

  // POST /locacoes/:id/retirada
  async registrarRetirada(req: Request, res: Response, next: NextFunction) {
    try {
      const id = Number(req.params.id);
      const locacao = await locacaoService.registrarRetirada(id, req.body);
      return res.status(200).json({
        status: 'success',
        message: 'Retirada do veículo registrada com sucesso. Locação em andamento.',
        data: locacao,
      });
    } catch (error) {
      return next(error);
    }
  }

  // POST /locacoes/:id/devolucao - Devolução e Fechamento (Endpoint Complexo 2)
  async registrarDevolucao(req: Request, res: Response, next: NextFunction) {
    try {
      const id = Number(req.params.id);
      const gestorId = req.user?.id;
      const locacao = await locacaoService.registrarDevolucao(id, req.body, gestorId);
      return res.status(200).json({
        status: 'success',
        message: 'Devolução registrada com sucesso. Contrato finalizado.',
        data: locacao,
      });
    } catch (error) {
      return next(error);
    }
  }

  // POST /locacoes/:id/cancelar
  async cancelar(req: Request, res: Response, next: NextFunction) {
    try {
      const id = Number(req.params.id);
      const locacao = await locacaoService.cancelar(id, req.body);
      return res.status(200).json({
        status: 'success',
        message: 'Locação cancelada e período liberado com sucesso',
        data: locacao,
      });
    } catch (error) {
      return next(error);
    }
  }
}

