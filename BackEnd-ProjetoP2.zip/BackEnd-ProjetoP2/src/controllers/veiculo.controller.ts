import { Request, Response, NextFunction } from 'express';
import { VeiculoService } from '../services/veiculo.service.js';

const veiculoService = new VeiculoService();

export class VeiculoController {
  async criar(req: Request, res: Response, next: NextFunction) {
    try {
      const veiculo = await veiculoService.criar(req.body);
      return res.status(201).json({
        status: 'success',
        data: veiculo,
      });
    } catch (error) {
      return next(error);
    }
  }

  async listar(req: Request, res: Response, next: NextFunction) {
    try {
      const veiculos = await veiculoService.listar(req.query);
      return res.status(200).json({
        status: 'success',
        total: veiculos.length,
        data: veiculos,
      });
    } catch (error) {
      return next(error);
    }
  }

  async buscarPorId(req: Request, res: Response, next: NextFunction) {
    try {
      const id = Number(req.params.id);
      const veiculo = await veiculoService.buscarPorId(id);
      return res.status(200).json({
        status: 'success',
        data: veiculo,
      });
    } catch (error) {
      return next(error);
    }
  }

  async atualizar(req: Request, res: Response, next: NextFunction) {
    try {
      const id = Number(req.params.id);
      const veiculo = await veiculoService.atualizar(id, req.body);
      return res.status(200).json({
        status: 'success',
        message: 'Veículo atualizado com sucesso',
        data: veiculo,
      });
    } catch (error) {
      return next(error);
    }
  }

  async remover(req: Request, res: Response, next: NextFunction) {
    try {
      const id = Number(req.params.id);
      const resultado = await veiculoService.inativarOuRemover(id);
      return res.status(200).json({
        status: 'success',
        message: 'Veículo bloqueado ou removido com sucesso',
        data: resultado,
      });
    } catch (error) {
      return next(error);
    }
  }

  async consultarDisponibilidade(req: Request, res: Response, next: NextFunction) {
    try {
      const { inicio, fim, veiculoId } = req.query as any;
      const resultado = await veiculoService.consultarDisponibilidade({
        inicio,
        fim,
        veiculoId: veiculoId ? Number(veiculoId) : undefined,
      });
      return res.status(200).json({
        status: 'success',
        data: resultado,
      });
    } catch (error) {
      return next(error);
    }
  }
}

