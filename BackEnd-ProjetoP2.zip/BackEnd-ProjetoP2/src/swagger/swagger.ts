import swaggerJSDoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import { Express } from 'express';

const options: swaggerJSDoc.Options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'AutoRent API - Gestão e Locação de Veículos',
      version: '1.0.0',
      description:
        'API REST desenvolvida para a disciplina de Desenvolvimento Back-End (FATEC TSI 3º Termo) - Professor Vinícius Hungaro.\n\n' +
        'Atende ao catálogo de requisitos funcionais da ERN AutoRent v1.0, com controle de frota, clientes, reservas, ciclo de vida da locação, tratamento de concorrência com transações atômicas e cálculo rigoroso de diárias e atrasos.',
      contact: {
        name: 'Equipe AutoRent - FATEC TSI',
      },
    },
    servers: [
      {
        url: 'http://localhost:3000',
        description: 'Servidor de Desenvolvimento Local',
      },
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description: 'Insira o token JWT gerado na rota /auth/login',
        },
      },
    },
  },
  apis: ['./src/routes/*.ts', './dist/routes/*.js'],
};

const swaggerSpec = swaggerJSDoc(options);

export function setupSwagger(app: Express) {
  app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
  app.get('/docs.json', (_req, res) => {
    res.setHeader('Content-Type', 'application/json');
    res.send(swaggerSpec);
  });
}

