# 🚗 AutoRent API - Sistema de Gestão e Locação de Veículos

Projeto prático desenvolvido para a disciplina de **Desenvolvimento Back-End** do curso superior de Tecnologia em Sistemas para Internet (**FATEC** - 3º Termo).  
**Professor:** Vinícius Hungaro  
**Versão:** 1.0 (Conforme Especificação de Regras de Negócio ERN AutoRent v1.0)

---

## 📌 1. Visão Geral e Contextualização do Negócio

A **AutoRent** é uma API REST corporativa projetada para centralizar e automatizar o ciclo operacional de uma locadora de veículos físicos. A aplicação resolve problemas críticos do setor automotivo:
- **Prevenção de reservas conflitantes:** algoritmo de detecção de sobreposição temporal de frotas no intervalo `[início, término)`.
- **Controle de elegibilidade:** validação rigorosa de condutores (idade mínima de 21 anos na retirada e CNH válida durante todo o período).
- **Tarifação dinâmica e sem tolerância:** cálculo de diárias integrais por teto de 24 horas (`ceil(horas/24)`) e apuração automática de atrasos na devolução.
- **Rastreabilidade e integridade:** transações atômicas com ACID (`prisma.$transaction`) que impedem concorrência desleal e estados parciais.
- **Gestão de manutenção e bloqueios:** entrada e saída de manutenção com tratamento de pendências operacionais automáticas ao término de contratos.

> **Nota:** A operação é restrita a funcionários autorizados (**Atendentes** e **Gestores**). O cliente não acessa o back-end diretamente.

---

## 🛠️ 2. Tecnologias Utilizadas

- **Linguagem:** [TypeScript](https://www.typescriptlang.org/) (Tipagem estática, interfaces e decorators)
- **Runtime:** [Node.js](https://nodejs.org/) (v20+)
- **Framework Web:** [Express.js](https://expressjs.com/)
- **ORM:** [Prisma ORM](https://www.prisma.io/) (com migrações declarativas e Client type-safe)
- **Banco de Dados:** [MySQL 8.0](https://www.mysql.com/)
- **Documentação Interativa:** [Swagger / OpenAPI 3.0](https://swagger.io/) (`swagger-ui-express` & `swagger-jsdoc`)
- **Validação de Schemas e DTOs:** [Zod](https://zod.dev/)
- **Segurança & Criptografia:** [JWT](https://jwt.io/) (JSON Web Tokens) e [bcryptjs](https://github.com/dcodeIO/bcrypt.js)
- **Ambiente Containerizado:** [Docker & Docker Compose](https://www.docker.com/)

---

## 🏛️ 3. Arquitetura em Camadas

A arquitetura do projeto segue a separação estrita de responsabilidades em camadas limpas:

```text
autorent-api/
├── prisma/
│   ├── schema.prisma          # Modelagem relacional para MySQL
│   └── seed.ts                # Povoamento inicial de usuários, clientes e veículos
├── src/
│   ├── @types/                # Extensões de tipagem do Express (Request.user)
│   ├── config/                # Carregamento e validação de variáveis de ambiente com Zod
│   ├── database/              # Instância singleton do PrismaClient
│   ├── errors/                # Classe customizada AppError para exceções de domínio
│   ├── middlewares/           # Autenticação JWT, autorização RBAC, validação Zod e errorHandler global
│   ├── schemas/               # Schemas Zod para validação rigorosa dos payloads
│   ├── services/              # Camada de Regras de Negócio (incluindo os Endpoints Complexos)
│   ├── controllers/           # Adaptadores HTTP (recepção de requisições e respostas)
│   ├── routes/                # Roteamento e anotações Swagger JSDoc
│   ├── swagger/               # Configuração OpenAPI 3.0
│   ├── app.ts                 # Configuração do Express e Middlewares
│   └── server.ts              # Ponto de entrada e inicialização do servidor HTTP
├── docker-compose.yml         # Orquestração do MySQL 8
├── tsconfig.json              # Configurações do compilador TypeScript
├── .env.example               # Modelo das variáveis de ambiente
└── README.md                  # Documentação completa do projeto
```

---

## 🗄️ 4. Modelagem de Dados Relacional (ER)

```mermaid
erDiagram
    Usuario ||--o{ Manutencao : "registra"
    Cliente ||--o{ Locacao : "contrata"
    Veiculo ||--o{ Locacao : "e_locado"
    Veiculo ||--o{ Manutencao : "sofre"

    Usuario {
        int id PK
        string nome
        string email UK
        string senhaHash
        enum papel "ATENDENTE | GESTOR"
        boolean ativo
        datetime criadoEm
    }

    Cliente {
        int id PK
        string nome
        string cpf UK
        date dataNascimento
        string cnh UK
        date validadeCnh
        string telefone
        string email
        enum situacao "ATIVO | INATIVO"
        datetime criadoEm
    }

    Veiculo {
        int id PK
        string placa UK
        string marca
        string modelo
        int ano
        int quilometragem
        decimal tarifaDiaria
        enum situacao "DISPONIVEL | LOCADO | EM_MANUTENCAO | BLOQUEADO"
        datetime criadoEm
    }

    Locacao {
        int id PK
        string codigoContrato UK
        int clienteId FK
        int veiculoId FK
        datetime retiradaPrevista
        datetime devolucaoPrevista
        datetime retiradaEfetiva
        datetime devolucaoEfetiva
        int kmInicial
        int kmFinal
        int diariasContratadas
        decimal tarifaContratada
        decimal valorPrevisto
        int diariasAtraso
        decimal valorAdicionalAtraso
        decimal valorFinal
        enum situacao "CONFIRMADA | EM_ANDAMENTO | FINALIZADA | CANCELADA"
    }

    Manutencao {
        int id PK
        int veiculoId FK
        string motivo
        boolean pendenteAposLocacao
        boolean finalizada
        datetime dataInicio
        datetime dataFim
        int registradoPorId FK
    }
```

---

## 🚦 5. Catálogo de Endpoints (19 Rotas Mapeadas)

A API supera a exigência mínima de 13 endpoints do edital, contemplando **3 CRUDs completos**, **autenticação com RBAC** e **2 endpoints com regras de negócio complexas**:

### 🔐 Autenticação
| Método | Endpoint | Papel | Descrição |
| :--- | :--- | :--- | :--- |
| `POST` | `/auth/login` | Público | Autenticação de atendente ou gestor e geração de token JWT |

### 👥 CRUD 1: Clientes (RF001 / UC001, UC002)
| Método | Endpoint | Papel | Descrição |
| :--- | :--- | :--- | :--- |
| `POST` | `/clientes` | Atendente/Gestor | Cadastro de cliente com validação de CPF e CNH únicos |
| `GET` | `/clientes` | Atendente/Gestor | Listagem geral com filtros (nome, CPF, situação) |
| `GET` | `/clientes/:id` | Atendente/Gestor | Detalhes do cliente e histórico recente de locações |
| `PUT` | `/clientes/:id` | Atendente/Gestor | Atualização de dados cadastrais |
| `DELETE`| `/clientes/:id` | Gestor | Inativação lógica (*soft delete*) preservando histórico |

### 🚙 CRUD 2: Frota de Veículos (RF002 / UC003)
| Método | Endpoint | Papel | Descrição |
| :--- | :--- | :--- | :--- |
| `POST` | `/veiculos` | Gestor | Cadastro de veículo com placa única e tarifa positiva |
| `GET` | `/veiculos` | Atendente/Gestor | Listagem de veículos com filtros (marca, modelo, situação) |
| `GET` | `/veiculos/:id` | Atendente/Gestor | Consulta de veículo e histórico de manutenções |
| `PUT` | `/veiculos/:id` | Gestor | Atualização de dados cadastrais e tarifa diária |
| `DELETE`| `/veiculos/:id` | Gestor | Bloqueio ou remoção da frota |
| `GET` | `/veiculos/disponibilidade` | Atendente/Gestor | **(RF003)** Consulta de veículos livres no período `[início, fim)` |

### 🔧 CRUD 3: Manutenções e Bloqueios (RF011 / UC010)
| Método | Endpoint | Papel | Descrição |
| :--- | :--- | :--- | :--- |
| `POST` | `/manutencoes` | Gestor | Registrar manutenção imediata ou pendência pós-devolução |
| `GET` | `/manutencoes` | Atendente/Gestor | Listagem de manutenções registradas e pendentes |
| `GET` | `/manutencoes/:id` | Atendente/Gestor | Detalhes do registro de manutenção |
| `PUT` | `/manutencoes/:id/finalizar` | Gestor | Concluir manutenção e liberar veículo para a frota |

### 📑 Ciclo de Vida da Locação (O Core do Negócio)
| Método | Endpoint | Papel | Descrição |
| :--- | :--- | :--- | :--- |
| `POST` | `/locacoes` | Atendente/Gestor | **🔥 [ENDPOINT COMPLEXO 1]** Contratação com transação atômica (`prisma.$transaction`), checagem de elegibilidade do cliente (idade 21+, CNH válida no período todo), cálculo de diárias `ceil(horas/24)` e bloqueio de concorrência temporal. |
| `GET` | `/locacoes` | Atendente/Gestor | Listagem geral com filtros (cliente, veículo, status) |
| `GET` | `/locacoes/:id` | Atendente/Gestor | Consulta completa do contrato e valores apurados |
| `POST` | `/locacoes/:id/retirada`| Atendente/Gestor | **(RF007)** Registro de entrega física, validação anti-antecipação e mudança para `EM_ANDAMENTO` |
| `POST` | `/locacoes/:id/devolucao`| Atendente/Gestor | **🔥 [ENDPOINT COMPLEXO 2]** Devolução com validação `kmFinal >= kmInicial`, apuração de atraso por diárias sem tolerância, cálculo do total e aplicação de manutenção pendente. |
| `POST` | `/locacoes/:id/cancelar` | Atendente/Gestor | **(RF006)** Cancelamento de contrato `CONFIRMADA` e liberação imediata da reserva |

---

## ⚡ 6. Passo a Passo para Execução

### Pré-requisitos
- [Node.js](https://nodejs.org/) v20 ou superior
- [Docker & Docker Compose](https://www.docker.com/) (ou MySQL local na porta 3306)

### 1. Clonar o repositório e acessar o diretório
```bash
git clone https://github.com/SEU_USUARIO/BackEnd-ProjetoP2.git
cd BackEnd-ProjetoP2
```

### 2. Configurar o arquivo de ambiente (.env)
Copie o modelo pré-configurado:
```bash
cp .env.example .env
```

### 3. Subir o Banco de Dados MySQL via Docker
```bash
docker compose up -d
```
> O container `autorent-mysql` subirá na porta `3306` com usuário `root` e senha `root`.

### 4. Executar as Migrações do Prisma e Gerar o Client
```bash
npm run prisma:migrate
npm run prisma:generate
```

### 5. Popular a Base de Dados (Seed Automático)
```bash
npm run prisma:seed
```

### 6. Iniciar a API em Modo de Desenvolvimento
```bash
npm run dev
```

A API estará disponível em: **`http://localhost:3000`**  
Acesse a documentação Swagger interativa em: **`http://localhost:3000/docs`**

---

## 🔑 7. Credenciais Padrão para Testes e Apresentação

O script de seed pré-cadastra dois perfis para demonstração ao vivo:

| Perfil | E-mail | Senha | Permissões |
| :--- | :--- | :--- | :--- |
| **Gestor (Administrador)** | `gestor@autorent.com` | `admin123` | Acesso total (frota, tarifas, manutenções, clientes e locações) |
| **Atendente** | `atendente@autorent.com` | `atendente123` | Operações diárias (clientes, disponibilidade, contratação, retirada e devolução) |

---

## 🎯 8. Roteiro de Demonstração (Critérios de Aceite CA001 a CA014)

Para a apresentação de **40 a 50 minutos** perante o professor **Vinícius Hungaro**, utilize a sequência de testes abaixo:

1. **CA001 / CA002 (Clientes):** Cadastrar cliente com sucesso via Swagger (`POST /clientes`); tentar cadastrar novamente com o mesmo CPF e demonstrar o retorno `409 Conflict`.
2. **CA003 / CA004 (Contratação & Conflito):** Criar locação para o veículo 1 no período de 01 a 04/dezembro (`POST /locacoes`). Tentar criar uma segunda locação para o mesmo veículo com sobreposição (ex: 03 a 06/dezembro) e observar a recusa automática com `409 Conflict`.
3. **CA005 / CA006 (Retirada Anti-Antecipada):** Tentar registrar a retirada antes do horário contratado (`POST /locacoes/:id/retirada`) e observar a recusa `400`. Enviar o horário válido, confirmar a entrega do veículo e demonstrar que o veículo passou para `LOCADO` e a locação para `EM_ANDAMENTO`.
4. **CA008 / CA009 (Devolução & Cálculo de Atraso):** Tentar registrar devolução com odômetro menor que o inicial (erro `400`). Registrar devolução com 5 horas de atraso e demonstrar a apuração automática de 1 diária adicional sem tolerância e status `FINALIZADA`.
5. **CA010 / CA011 (Manutenção Automática):** Indicar necessidade de manutenção na devolução ou cadastrar pendência pelo Gestor e comprovar que o veículo passa automaticamente para `EM_MANUTENCAO`.

---

## 📄 Licença e Integrantes

Trabalho acadêmico submetido para avaliação da disciplina de Desenvolvimento Back-End — Faculdade de Tecnologia (**FATEC**).

